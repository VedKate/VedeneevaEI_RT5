﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Lab3
{
    interface IPrint
    {
        void Print();
    }

        class Program
        {

            static void Main(string[] args)
            {
                Console.WriteLine("Веденеева Екатерина РТ5-31Б Лабораторная 2");
                Rectangle r = new Rectangle(2, 4);
                Square s = new Square(4);
                Circle c = new Circle(1);
            /*
                r.Print();
                s.Print();
                c.Print();
            */

            var L = new List<Figure> { r, s, c };
            
            
            foreach (Figure n in L)
                Console.WriteLine(n.ToString());
                Console.WriteLine( " ");
            L.Sort();

            //Console.WriteLine("Сортировка необобщенного списка");
            
            foreach (Figure n in L)
                Console.WriteLine(n.ToString());

            Console.WriteLine("\nМатрица");
            Matrix<Figure> matrix = new Matrix<Figure>(3, 3, 3,new FigureMatrixCheckEmpty());
            matrix[0, 0,0] = r;
            matrix[1, 1,0] = s;
            matrix[2, 2,0] = c;
            Console.WriteLine(matrix.ToString());
            
            SimpleStack<Figure> stack = new SimpleStack<Figure>();
            //добавление данных в стек
            stack.Push(r);
            stack.Push(s);
            stack.Push(c);
            //чтение данных из стека
            while (stack.Count > 0)
            {
                Figure f = stack.Pop();
                Console.WriteLine(f);
            }
            
            Console.ReadLine();
            }

     }
}
