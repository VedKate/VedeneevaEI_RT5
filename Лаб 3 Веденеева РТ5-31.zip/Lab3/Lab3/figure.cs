﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{     
        
    abstract class Figure : IComparable<Figure>
    {
        public int CompareTo(Figure o)
        {
            Figure f = o as Figure;
            //Если площадь текущего элемента больше площади сравнваемого элемента, текущий должен стояь перед
            if (this.Calculate_area() > f.Calculate_area())
                return -1;
            if (this.Calculate_area() < f.Calculate_area())
                return 1;
            if (this.Calculate_area() == f.Calculate_area())
                return 0;
            else
                throw new Exception("Невозможно сравнить два объекта");

        }

            /// <summary>
            /// Абстрактный клас "Геометрическая фгура"
            /// </summary>
        
            /// <summary>
            /// Тип фигуры
            /// </summary>
            public string Type
            {
                get
                {
                    return this._Type;
                }
                protected set
                {
                    this._Type = value;
                }
            }
            private string _Type;
            public virtual double Calculate_area()
                {
                    return 0;
            }
            /// <summary>
            /// Приведение к строке, переопределение метода Object
             /// </summary>
            public override string ToString()
            {
                return this.Type + " площадью " +
               this.Calculate_area().ToString();
            }

            }

}
