﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{
    /// <summary>
    /// Класс "Прямоугольник", наследник Г.ф.
    /// </summary>
    class Rectangle : Figure, IPrint
    {
        public Rectangle(int h, int w)
        {
            Height = h;
            Width = w;
            this.Type = "Прямоугольник";

        }
        private int _height;
        public int Height
        {
            get { return _height; }
            set { _height = value; }
        }
        private int _width;
        public int Width
        {
            get { return _width; }
            set { _width = value; }
        }
        public override double Calculate_area()
        {
            return Height * Width;
        }

        public void Print()
        {
            Console.WriteLine(this.ToString());
        }

    }

}
