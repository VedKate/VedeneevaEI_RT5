﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{
    /// <summary>
    /// Класс "Круг", наследник Г.Ф.
    /// </summary>
    class Circle : Figure, IPrint
    {
        public Circle(int r)
        {
            Radius = r;
            this.Type = "Круг";
        }

        private int _radius;
        public int Radius
        {
            get { return _radius; }
            set { _radius = value; }
        }
        public override double Calculate_area()
        {
            return 3.14 * Radius * Radius;
        }

        public void Print()
        {
            Console.WriteLine(this.ToString());
        }

    }

}
