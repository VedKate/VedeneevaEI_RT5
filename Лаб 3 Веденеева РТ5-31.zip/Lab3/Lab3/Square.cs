﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{
    /// <summary>
    /// Класс "Квадрат", наследник "Прямоугольника"
    /// </summary>
    class Square : Rectangle, IPrint
    {
        public Square(int l) : base(l, 0)
        {
            Height = l;
            Width = l;
            this.Type = "Квадрат";
        }

        new public void Print()
        {
            Console.WriteLine(this.ToString());
        }
    }

}
