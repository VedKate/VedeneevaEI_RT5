﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        /// <summary>
        /// Использование основных операторов
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Веденеева Екатерина РТ5-31Б");
            double a, b, c;
            string sa, sb, sc;

            a = double.Parse(sa = Console.ReadLine());

            b = double.Parse(sb = Console.ReadLine());

            c = double.Parse(sc = Console.ReadLine());

            double d = b * b - 4 * a * c;

            // Дискриминант больше нуля - "первичнвх" корня два
            if (d > 0)
            {
                //Console.WriteLine("Here");
                d = Math.Pow(d, 0.5);
                double y1 = (-b + d) / (2 * a);
                double y2 = (-b - d) / (2 * a);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Корни:");

                // Разбиение первого квадрата
                if (y1 > 0)
                {
                    Console.WriteLine(Math.Pow(y1, 0.5));
                    Console.WriteLine(-1 * Math.Pow(y1, 0.5));
                }
                else if (y1 < 0)
                {
                    Console.WriteLine(Math.Sqrt(Math.Abs(y1)));
                    Console.WriteLine(-1 * Math.Sqrt(Math.Abs(y1)));
                }
                else
                {
                    Console.WriteLine("0 кратности 2");
                }

                // Разбиение второго квадрата
                if (y2 > 0)
                {

                    Console.WriteLine(Math.Pow(y2, 0.5));
                    Console.WriteLine(-1 * Math.Pow(y2, 0.5));

                }
                else if (y2 < 0)
                {

                    Console.WriteLine("i*" + Math.Sqrt(Math.Abs(y2)));
                    Console.WriteLine("i*" + -1 * Math.Sqrt(Math.Abs(y2)));
                    Console.ResetColor();
                }
                else
                {

                    Console.WriteLine("0 кратности 2");
                }

                /*
                Console.WriteLine(a);
                Console.WriteLine(b);
                Console.WriteLine(c);
                */
                // Console.WriteLine("Корни:");
                //  Console.WriteLine(y1);
                //  Console.WriteLine(y2);
                Console.ResetColor();
            }
            // Дискриминант равен нулю - "первичный" корень один кратности 2
            else if (d == 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                double y = (-b) / (2 * a);

                if (y > 0)
                {
                    Console.WriteLine(Math.Pow(y, 0.5));
                    Console.WriteLine(-1 * Math.Pow(y, 0.5));
                }
                else if (y < 0)
                {
                    Console.WriteLine("i*", Math.Sqrt(Math.Abs(y)));
                    Console.WriteLine("-i*", Math.Sqrt(Math.Abs(y)));
                }
                else
                {
                    Console.WriteLine("0 кратности 4");
                }
                Console.ResetColor();
            }
            // Дискриминант меньше нуля - нет рациональных "первичных" корней
            else if (d < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Рациональных первичных корней нет");
                Console.ResetColor();
            }
            string k = Console.ReadLine();
        }
    }
}
