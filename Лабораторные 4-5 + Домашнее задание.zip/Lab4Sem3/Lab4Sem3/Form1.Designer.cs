﻿namespace Lab4Sem3
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonLoadFile = new System.Windows.Forms.Button();
            this.textBoxFileReadTime = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxFileReadCount = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxFind = new System.Windows.Forms.TextBox();
            this.buttonExact = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxExactTime = new System.Windows.Forms.TextBox();
            this.listBoxResult = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxStreams = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.MaxLable = new System.Windows.Forms.Label();
            this.textBoxMaxL = new System.Windows.Forms.TextBox();
            this.textBoxSTimer = new System.Windows.Forms.TextBox();
            this.StreamsTimer = new System.Windows.Forms.Label();
            this.StreamsQuant = new System.Windows.Forms.Label();
            this.textBoxSQuant = new System.Windows.Forms.TextBox();
            this.textBoxOtchet = new System.Windows.Forms.TextBox();
            this.Otchet = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonLoadFile
            // 
            this.buttonLoadFile.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonLoadFile.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonLoadFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonLoadFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonLoadFile.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonLoadFile.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonLoadFile.Location = new System.Drawing.Point(50, 41);
            this.buttonLoadFile.Name = "buttonLoadFile";
            this.buttonLoadFile.Size = new System.Drawing.Size(281, 51);
            this.buttonLoadFile.TabIndex = 0;
            this.buttonLoadFile.Text = "Чтение из файла";
            this.buttonLoadFile.UseVisualStyleBackColor = false;
            this.buttonLoadFile.Click += new System.EventHandler(this.buttonLoadFile_Click);
            // 
            // textBoxFileReadTime
            // 
            this.textBoxFileReadTime.Location = new System.Drawing.Point(844, 52);
            this.textBoxFileReadTime.Name = "textBoxFileReadTime";
            this.textBoxFileReadTime.ReadOnly = true;
            this.textBoxFileReadTime.Size = new System.Drawing.Size(347, 31);
            this.textBoxFileReadTime.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(444, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(250, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Время чтения из файла";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(444, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(394, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Количество уникальных слов в файле";
            // 
            // textBoxFileReadCount
            // 
            this.textBoxFileReadCount.Location = new System.Drawing.Point(844, 114);
            this.textBoxFileReadCount.Name = "textBoxFileReadCount";
            this.textBoxFileReadCount.ReadOnly = true;
            this.textBoxFileReadCount.Size = new System.Drawing.Size(347, 31);
            this.textBoxFileReadCount.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(152, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Поиск";
            // 
            // textBoxFind
            // 
            this.textBoxFind.Location = new System.Drawing.Point(246, 209);
            this.textBoxFind.Name = "textBoxFind";
            this.textBoxFind.Size = new System.Drawing.Size(333, 31);
            this.textBoxFind.TabIndex = 6;
            // 
            // buttonExact
            // 
            this.buttonExact.Location = new System.Drawing.Point(598, 205);
            this.buttonExact.Name = "buttonExact";
            this.buttonExact.Size = new System.Drawing.Size(141, 39);
            this.buttonExact.TabIndex = 7;
            this.buttonExact.Text = "Искать";
            this.buttonExact.UseVisualStyleBackColor = true;
            this.buttonExact.Click += new System.EventHandler(this.buttonExact_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(778, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Время поиска";
            // 
            // textBoxExactTime
            // 
            this.textBoxExactTime.Location = new System.Drawing.Point(937, 212);
            this.textBoxExactTime.Name = "textBoxExactTime";
            this.textBoxExactTime.ReadOnly = true;
            this.textBoxExactTime.Size = new System.Drawing.Size(254, 31);
            this.textBoxExactTime.TabIndex = 9;
            // 
            // listBoxResult
            // 
            this.listBoxResult.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.listBoxResult.FormattingEnabled = true;
            this.listBoxResult.ItemHeight = 25;
            this.listBoxResult.Location = new System.Drawing.Point(67, 592);
            this.listBoxResult.Name = "listBoxResult";
            this.listBoxResult.Size = new System.Drawing.Size(1124, 254);
            this.listBoxResult.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(105, 378);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(226, 58);
            this.button1.TabIndex = 11;
            this.button1.Text = "Многопотоковый поиск";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxStreams
            // 
            this.textBoxStreams.Location = new System.Drawing.Point(795, 319);
            this.textBoxStreams.Name = "textBoxStreams";
            this.textBoxStreams.Size = new System.Drawing.Size(300, 31);
            this.textBoxStreams.TabIndex = 12;
            this.textBoxStreams.TextChanged += new System.EventHandler(this.textBoxStreams_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(572, 322);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(215, 25);
            this.label5.TabIndex = 13;
            this.label5.Text = "Количество потоков";
            // 
            // MaxLable
            // 
            this.MaxLable.AutoSize = true;
            this.MaxLable.Location = new System.Drawing.Point(378, 378);
            this.MaxLable.Name = "MaxLable";
            this.MaxLable.Size = new System.Drawing.Size(409, 25);
            this.MaxLable.TabIndex = 14;
            this.MaxLable.Text = "Макссимальное допустимое рассояние";
            // 
            // textBoxMaxL
            // 
            this.textBoxMaxL.Location = new System.Drawing.Point(795, 372);
            this.textBoxMaxL.Name = "textBoxMaxL";
            this.textBoxMaxL.Size = new System.Drawing.Size(300, 31);
            this.textBoxMaxL.TabIndex = 15;
            // 
            // textBoxSTimer
            // 
            this.textBoxSTimer.Location = new System.Drawing.Point(795, 421);
            this.textBoxSTimer.Name = "textBoxSTimer";
            this.textBoxSTimer.ReadOnly = true;
            this.textBoxSTimer.Size = new System.Drawing.Size(300, 31);
            this.textBoxSTimer.TabIndex = 16;
            // 
            // StreamsTimer
            // 
            this.StreamsTimer.AutoSize = true;
            this.StreamsTimer.Location = new System.Drawing.Point(458, 424);
            this.StreamsTimer.Name = "StreamsTimer";
            this.StreamsTimer.Size = new System.Drawing.Size(329, 25);
            this.StreamsTimer.TabIndex = 17;
            this.StreamsTimer.Text = "Время многопотокового поиска";
            // 
            // StreamsQuant
            // 
            this.StreamsQuant.AutoSize = true;
            this.StreamsQuant.Location = new System.Drawing.Point(434, 480);
            this.StreamsQuant.Name = "StreamsQuant";
            this.StreamsQuant.Size = new System.Drawing.Size(353, 25);
            this.StreamsQuant.TabIndex = 18;
            this.StreamsQuant.Text = "Вычисленное количество потоков";
            // 
            // textBoxSQuant
            // 
            this.textBoxSQuant.Location = new System.Drawing.Point(795, 477);
            this.textBoxSQuant.Name = "textBoxSQuant";
            this.textBoxSQuant.ReadOnly = true;
            this.textBoxSQuant.Size = new System.Drawing.Size(299, 31);
            this.textBoxSQuant.TabIndex = 19;
            // 
            // textBoxOtchet
            // 
            this.textBoxOtchet.Location = new System.Drawing.Point(795, 524);
            this.textBoxOtchet.Name = "textBoxOtchet";
            this.textBoxOtchet.Size = new System.Drawing.Size(300, 31);
            this.textBoxOtchet.TabIndex = 21;
            // 
            // Otchet
            // 
            this.Otchet.AutoSize = true;
            this.Otchet.Location = new System.Drawing.Point(586, 527);
            this.Otchet.Name = "Otchet";
            this.Otchet.Size = new System.Drawing.Size(198, 25);
            this.Otchet.TabIndex = 22;
            this.Otchet.Text = "Имя файла-отчета";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1286, 969);
            this.Controls.Add(this.Otchet);
            this.Controls.Add(this.textBoxOtchet);
            this.Controls.Add(this.textBoxSQuant);
            this.Controls.Add(this.StreamsQuant);
            this.Controls.Add(this.StreamsTimer);
            this.Controls.Add(this.textBoxSTimer);
            this.Controls.Add(this.textBoxMaxL);
            this.Controls.Add(this.MaxLable);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxStreams);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBoxResult);
            this.Controls.Add(this.textBoxExactTime);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonExact);
            this.Controls.Add(this.textBoxFind);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxFileReadCount);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxFileReadTime);
            this.Controls.Add(this.buttonLoadFile);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonLoadFile;
        private System.Windows.Forms.TextBox textBoxFileReadTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxFileReadCount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxFind;
        private System.Windows.Forms.Button buttonExact;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxExactTime;
        private System.Windows.Forms.ListBox listBoxResult;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxStreams;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label MaxLable;
        private System.Windows.Forms.TextBox textBoxMaxL;
        private System.Windows.Forms.TextBox textBoxSTimer;
        private System.Windows.Forms.Label StreamsTimer;
        private System.Windows.Forms.Label StreamsQuant;
        private System.Windows.Forms.TextBox textBoxSQuant;
        private System.Windows.Forms.TextBox textBoxOtchet;
        private System.Windows.Forms.Label Otchet;
    }
}

