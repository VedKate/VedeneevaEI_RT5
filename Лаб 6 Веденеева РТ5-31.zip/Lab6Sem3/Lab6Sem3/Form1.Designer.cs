﻿namespace Lab6Sem3
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelStr1 = new System.Windows.Forms.Label();
            this.labelStr2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.labelInt0 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SterterB = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.startRef = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // labelStr1
            // 
            this.labelStr1.AutoSize = true;
            this.labelStr1.Location = new System.Drawing.Point(159, 161);
            this.labelStr1.Name = "labelStr1";
            this.labelStr1.Size = new System.Drawing.Size(120, 25);
            this.labelStr1.TabIndex = 0;
            this.labelStr1.Text = "Тут срочку";
            // 
            // labelStr2
            // 
            this.labelStr2.AutoSize = true;
            this.labelStr2.Location = new System.Drawing.Point(161, 234);
            this.labelStr2.Name = "labelStr2";
            this.labelStr2.Size = new System.Drawing.Size(148, 25);
            this.labelStr2.TabIndex = 1;
            this.labelStr2.Text = "И тут строчку";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(399, 166);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(243, 31);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(399, 231);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(243, 31);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(401, 304);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(240, 31);
            this.textBox3.TabIndex = 4;
            // 
            // labelInt0
            // 
            this.labelInt0.AutoSize = true;
            this.labelInt0.Location = new System.Drawing.Point(173, 311);
            this.labelInt0.Name = "labelInt0";
            this.labelInt0.Size = new System.Drawing.Size(162, 25);
            this.labelInt0.TabIndex = 5;
            this.labelInt0.Text = "А тут цыфИрку";
            this.labelInt0.Click += new System.EventHandler(this.label3_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Location = new System.Drawing.Point(29, 411);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(1243, 179);
            this.listBox1.TabIndex = 6;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // SterterB
            // 
            this.SterterB.Location = new System.Drawing.Point(975, 193);
            this.SterterB.Name = "SterterB";
            this.SterterB.Size = new System.Drawing.Size(136, 41);
            this.SterterB.TabIndex = 7;
            this.SterterB.Text = "Туть";
            this.SterterB.UseVisualStyleBackColor = true;
            this.SterterB.Click += new System.EventHandler(this.SterterB_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // startRef
            // 
            this.startRef.Location = new System.Drawing.Point(930, 320);
            this.startRef.Name = "startRef";
            this.startRef.Size = new System.Drawing.Size(218, 36);
            this.startRef.TabIndex = 9;
            this.startRef.Text = "Рефллексия";
            this.startRef.UseVisualStyleBackColor = true;
            this.startRef.Click += new System.EventHandler(this.startRef_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 25;
            this.listBox2.Location = new System.Drawing.Point(39, 626);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(1232, 279);
            this.listBox2.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1870, 1005);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.startRef);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SterterB);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.labelInt0);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelStr2);
            this.Controls.Add(this.labelStr1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelStr1;
        private System.Windows.Forms.Label labelStr2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label labelInt0;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button SterterB;
        private System.Windows.Forms.Button button1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button startRef;
        private System.Windows.Forms.ListBox listBox2;
    }
}

