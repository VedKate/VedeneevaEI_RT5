﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;


namespace Lab6Sem3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void SterterB_Click(object sender, EventArgs e)
        {
            //Достаем данные из текствоксов
            string str1 = textBox1.Text.Trim();
            string str2 = textBox2.Text.Trim();
            string intVal = textBox3.Text.Trim();

            Delegates.TBConverter<string, string, int, string> Statement1 = Delegates.StrPlus;
            Delegates.TBConverter<string, string, int, string> Statement2 = Delegates.StrPlus;

            Delegates.TBConverter<Delegates.TBConverter<string, string, int, string>, string, string, string> Jora = Delegates.StatePlus;


            int TxtInt = Convert.ToInt32(intVal); // Получаем числовое значение из последнего строкового
            string sayThis;

            //Две переменных, удобных для подстановки
            string False = "ЛОЖЬ";
            string True = "ИСТИНЫ";

            // Какое-то условие для заключения, выводимого в конце строки 
            if (TxtInt == 0)
                sayThis = " при коньюнкции дают 0.";
            else if (TxtInt == 1)
                sayThis = " при импликации дают 1";
            else
                sayThis = " <- это конец делегата, принимающего делегат";


            // Вызываем и выводив первые два делегата
            this.listBox1.Items.Add("Отдельные делегаты, созданные через шаблон и функцию:");
            this.listBox1.Items.Add(Statement1(True, False, 0));
            this.listBox1.Items.Add(Statement2(str1, str2, TxtInt));





            ////////////////// НЕРАБОТАЮЩАЯ ХРЕНЬ ////////////////////////////////
            // Вызываем метод, принимающий делегат
            // С помошью метода для другого делегата
            this.listBox1.Items.Add("Метод, принимающий делегат в качетсве параметра - результат: ");
            this.listBox1.Items.Add(Jora(Statement1, "КОТИКА", "КУСИ"));
            //this.listBox1.Items.Add(Jora);
            //С помощью лямбда-выражения
            this.listBox1.Items.Add("Метод, принимающий делегат в качетсве параметра-делегата лямбда-выражение: ");

            Delegates.TBConverter<Delegates.TBConverter<string, string, int, string>, string, string, string> TestStatement = (Delegates.TBConverter<string, string, int, string> f1, string f2, string f3) =>
               {

                   string res = "ЭТО ПОЛНЫЙ БРЕД, НО НАДО ЧТО-ТО СЮДА ЗАПИСАТЬ: " + f1("ИСТИНЫ", "ЛОЖЬ", 1) + " и " + f2 + f3;
                   return res;
               };

            this.listBox1.Items.Add(TestStatement(Statement1, "ПРОВЕРКА 1", "ПРОВЕРКА 2"));






        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Запускае вывод сведений о проекте
        /// </summary>
        private void startRef_Click(object sender, EventArgs e)
        {

            this.listBox2.Items.Add("Вывод информации о сборке:");
            Assembly i = Assembly.GetExecutingAssembly();
            this.listBox2.Items.Add("Полное имя:" + i.FullName);
            this.listBox2.Items.Add("Исполняемый файл:" + i.Location);
            this.listBox2.Items.Add("");
            this.listBox2.Items.Add("");
            Delegates obj = new Delegates();
            Type File = obj.GetType();

            this.listBox2.Items.Add("\nИнформация о типе:");
            this.listBox2.Items.Add("Тип " + File.FullName + " унаследован от " + File.BaseType.FullName);
            this.listBox2.Items.Add("Пространство имен " + File.Namespace);
            this.listBox2.Items.Add("Находится в сборке " + File.AssemblyQualifiedName);
            this.listBox2.Items.Add("");
            this.listBox2.Items.Add("\nКонструкторы:");
            foreach (var x in File.GetConstructors())
            {
                this.listBox2.Items.Add(x);
            }
            this.listBox2.Items.Add("");
            this.listBox2.Items.Add("\nМетоды:");
            foreach (var x in File.GetMethods())
            {
                this.listBox2.Items.Add(x);
            }
            this.listBox2.Items.Add("");
            this.listBox2.Items.Add("\nСвойства:");
            foreach (var x in File.GetProperties())
            {
                this.listBox2.Items.Add(x);
            }
            this.listBox2.Items.Add("");
            this.listBox2.Items.Add("\nПоля данных (public):");
            foreach (var x in File.GetFields())
            {
                this.listBox2.Items.Add(x);
            }
            this.listBox2.Items.Add("");
            this.listBox2.Items.Add("\nForInspection реализует IComparable -> " + File.GetInterfaces().Contains(typeof(IComparable))
            );
        }

        class Delegates : IComparable
        {
            public int CompareTo(object obj)
            {
                return 0;
            }
            //Делегат
            public delegate T TBConverter<T0, T1, T2, T>(T0 d1, T1 d2, T2 int0);
            public delegate string TBState(TBConverter<string, string, string, string> f1, TBConverter<string, string, string, string> f2);

            //Методы, реализующие делегат (методы "типа" делегата) 
            public static string StrPlus(string str1, string str2, int i0)
            {

                return " из " + str1 + " следует " + str2 + " и поолучается " + i0.ToString();
            }
            public static string StatePlus(TBConverter<string, string, int, string> state1, string state2, string say)
            {
                return state1("АТЬ", "ДВА", 3) + state2 + say;
            }

            //Вызываем методы для заданных параметров

        }


    }
}
