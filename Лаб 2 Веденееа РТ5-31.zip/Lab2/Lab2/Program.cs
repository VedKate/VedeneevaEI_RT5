﻿using System;

namespace Lab2
{
    class Program
    {
        /// <summary>
        /// Абстрактный клас "Геометрическая фгура"
        /// </summary>
        abstract class Figure
        {
            //public int area;
            public virtual double Calculate_area()
            {
                return 0;
            }
        }

        /// <summary>
        /// Класс "Прямоугольник", наследник Г.ф.
        /// </summary>

        class Rectangle : Figure, IPrint
        {
            public Rectangle(int h, int w)
            {
                Height = h;
                Width = w;

            }
            private int _height;
            public int Height
            {
                get { return _height; }
                set { _height = value; }
            }
            private int _width;
            public int Width
            {
                get { return _width; }
                set { _width = value; }
            }
            public override double Calculate_area()
            {
                return Height * Width;
            }

            
            public override string ToString()
            {
                return "Прямоугольнк со сторонами " + Height + " и "
                       + Width + " площадью " + Calculate_area();
            }

            public void Print()
            {
                Console.WriteLine(ToString());
            }

        }


        /// <summary>
        /// Класс "Квадрат", наследник "Прямоугольника"
        /// </summary>

        class Square : Rectangle, IPrint
        {
            public Square(int l) : base(l, 0)
            {
                Height = l;
                Width = l;
            }
            public override string ToString()
            {
                return "Квадрат со стороной " + Height + " площадью " + Calculate_area();
            }

            new public void Print() {
                Console.WriteLine(ToString());
            }
        }


        /// <summary>
        /// Класс "Круг", наследник Г.Ф.
        /// </summary>

        class Circle : Figure, IPrint
        {
            public Circle(int r)
            {
                Radius = r;
            }
            private int _radius;
            public int Radius
            {
                get { return _radius; }
                set { _radius = value; }
            }
            public override double Calculate_area()
            {
                return 3.14 * Radius * Radius;
            }

            public override string ToString()
            {
                return "Круг с радусом " + Radius + " площадью " + Calculate_area();
            }
           
            public void Print()
            {
                Console.WriteLine(ToString());
            }

        }
        class APrint {
            public APrint(Rectangle r) {
                Console.WriteLine(r.ToString());
            }
            public APrint(Square s)
            {
                Console.WriteLine(s.ToString());
            }

            public APrint(Circle c)
            {
                Console.WriteLine(c.ToString());
            }
        }

        interface IPrint 
        {
            void Print();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Веденеева Екатерина РТ5-31Б Лабораторная 2");
           Rectangle r = new Rectangle(2,4);
           Square s = new Square(4);
           Circle c = new Circle(1);

            r.Print();
            s.Print();
            c.Print();

            int i = Console.Read();
        }
    }

}